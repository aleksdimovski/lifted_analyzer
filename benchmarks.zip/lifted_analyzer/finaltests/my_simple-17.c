

int main() {
  int i=0;

  #if (A1) i=i+1; #endif
  #if (A2) i=i+1; #endif
  #if (A3) i=i+1; #endif
  #if (A4) i=i+1; #endif
  #if (A5) i=i+1; #endif
  #if (A6) i=i+1; #endif
  #if (A7) i=i+1; #endif
  #if (A8) i=i+1; #endif
  #if (A9) i=i+1; #endif
  #if (A10) i=i+1; #endif
  #if (A11) i=i+1; #endif
  #if (A12) i=i+1; #endif
  #if (A13) i=i+1; #endif
  #if (A14) i=i+1; #endif	
  #if (A15) i=i+1; #endif
  #if (A16) i=i+1; #endif
  #if (A17) i=i+1; #endif

  return 0;
}